# 🤖 Bot WhatsApp – Clínica Blanquer (Meta Cloud API + Vercel)

Este pacote contém o **bot oficial** para WhatsApp (Cloud API) rodando como **Serverless Function** na **Vercel**.

## 📦 Conteúdo
- `api/webhook.js` – função serverless que verifica o webhook (GET) e responde mensagens (POST).
- `package.json` – dependências (axios).
- `vercel.json` – define runtime Node 18.x.
- (Opcional) Variáveis de ambiente na Vercel: `VERIFY_TOKEN`, `WHATSAPP_TOKEN`.

## 🚀 Deploy rápido (Vercel)
1. Crie uma conta em https://vercel.com e entre.
2. Clique em **New Project** → **Import** e selecione esta pasta.
3. Em **Settings → Environment Variables** crie:
   - `VERIFY_TOKEN` = `clinica_token` (ou outro que preferir)
   - `WHATSAPP_TOKEN` = **Cole aqui o token do painel Meta**
4. **Deploy**. Copie a URL pública (ex.: `https://clinica-bot.vercel.app`).

## 🔗 Conectar à Meta (Cloud API)
1. No **developers.facebook.com** → seu **App** → **WhatsApp → Configuration**.
2. Em **Webhook URL**, cole `https://SEU-APP.vercel.app/api/webhook`.
3. Em **Verify Token**, digite exatamente o que pôs em `VERIFY_TOKEN`.
4. Clique em **Verificar e salvar**.

## 🧪 Teste
- Envie uma mensagem **“oi”** para o **número de teste** do WhatsApp (mostrado no painel da Meta).
- Você receberá o **menu** com 4 opções.
- Envie **1**, **2**, **3** ou **4** e receba a resposta automática.

## 🛠 Personalização
- Edite as mensagens no arquivo `api/webhook.js` (funções `buildMenu` e `buildReply`).
- Para produção: verifique o negócio no **Business Manager**, registre o **número oficial**, gere **token permanente**, atualize `WHATSAPP_TOKEN` e faça novo deploy.
